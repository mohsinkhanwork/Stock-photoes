@extends('customer-portal.layout.customer')
@section('title', 'Profile')
@section('content')
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">

            </div>
        </div>
        <div class="content">
            <div class="container-fluid">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">{{__('customers-sidebar.profile')}}</h3>
                    </div>
                    <div class="card-body">
                        {{--@if(session()->has('message'))
                            <div class="alert alert-success">
                                {{ session()->get('message') }}
                            </div>
                        @endif
                        @if(session('error'))
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <strong> {{session('error')}}</strong>
                            </div>
                        @endif--}}
                        <div class="alert-block"></div>
                        <form name="update_customer_profile" id="update_customer_profile">
                            @csrf
                            <div class="row">
                                <div class="col-6">
                                    <div class="form-group row">
                                        <label for="name" class="col-sm-2 col-form-label">{{__('admin-customers.table_column_title')}}<strong class="text-danger">*</strong></label>
                                        <div class="col-sm-9">

                                            @if (/*auth()->guard('customer')->user()->phone_number && */auth()->guard('customer')->user()->road && auth()->guard('customer')->user()->post_code && auth()->guard('customer')->user()->place && auth()->guard('customer')->user()->country)
                                                <input  type="text" value="{{ auth()->guard('customer')->user()->title == 'mr' ? 'Herr':'Frau' }} (Zertifiziert)"
                                                        class="form-control-plaintext" disabled >
                                                <select name="title" id="title" class="form-control @error('title') is-invalid @enderror" hidden>
                                                    <option selected value="{{auth()->guard('customer')->user()->title}}">{{__('auth.customer_registration_form_input_title_mr')}}</option>

                                                </select>
                                            @else
                                                <select name="title" id="title" class="form-control @error('title') is-invalid @enderror">
                                                    <option value="">-</option>
                                                    <option {{ auth()->guard('customer')->user()->title == 'mr'  ? 'selected' : ''}} value="mr">{{__('auth.customer_registration_form_input_title_mr')}}</option>
                                                    <option {{ auth()->guard('customer')->user()->title == 'mrs' ? 'selected' : '' }}  value="mrs">{{__('auth.customer_registration_form_input_title_mrs')}}</option>
                                                </select>
                                                @error('title')
                                                <span class="invalid-feedback error" role="alert">
                                                        <!-- <strong>{{ $message }}</strong> -->
                                                            <strong>{{__('auth.customer_registration_form_alert_input_title')}}</strong>
                                                    </span>
                                                @enderror
                                            @endif

                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="name" class="col-sm-2 col-form-label">{{__('admin-customers.table_column_name')}}<strong class="text-danger">*</strong></label>
                                        <div class="col-sm-9">

                                            @if (/*auth()->guard('customer')->user()->phone_number &&*/ auth()->guard('customer')->user()->road && auth()->guard('customer')->user()->post_code && auth()->guard('customer')->user()->place && auth()->guard('customer')->user()->country)
                                                <input  type="text" value="{{ auth()->guard('customer')->user()->first_name }} (Zertifiziert)"
                                                        class="form-control-plaintext" disabled >
                                                <input  type="hidden"  name="first_name"  id="first_name" value="{{ auth()->guard('customer')->user()->first_name }}"  >
                                            @else
                                                <input  type="text" value="{{ auth()->guard('customer')->user()->first_name }}"
                                                        name="first_name"
                                                        id="first_name"
                                                        class="form-control @error('first_name') is-invalid @enderror"   >
                                                @error('first_name')
                                                <span class="invalid-feedback error" role="alert">
                                                        <!-- <strong>{{ $message }}</strong> -->
                                                            <strong>{{__('auth.customer_registration_form_alert_input_name')}}</strong>
                                                    </span>
                                                @enderror
                                            @endif

                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="name" class="col-sm-2 col-form-label">{{__('admin-customers.table_column_last_name')}}<strong class="text-danger">*</strong></label>
                                        <div class="col-sm-9">
                                            @if (/*auth()->guard('customer')->user()->phone_number &&*/ auth()->guard('customer')->user()->road && auth()->guard('customer')->user()->post_code && auth()->guard('customer')->user()->place && auth()->guard('customer')->user()->country)
                                                <input type="text" value="{{ auth()->guard('customer')->user()->last_name }} (Zertifiziert)"
                                                       class="form-control-plaintext" disabled >
                                                <input type="hidden"  name="last_name" id="last_name" value="{{ auth()->guard('customer')->user()->last_name }}" >
                                            @else
                                                <input type="text" value="{{ auth()->guard('customer')->user()->last_name }}"
                                                       name="last_name" id="last_name"
                                                       class="form-control @error('last_name') is-invalid @enderror"  >
                                                @error('last_name')
                                                <span class="invalid-feedback error" role="alert">
                                                        <!-- <strong>{{ $message }}</strong> -->
                                                            <strong>{{__('auth.customer_registration_form_alert_input_last_name')}}</strong>
                                                    </span>
                                                @enderror
                                            @endif

                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="name" class="col-sm-2 col-form-label">E-Mail <strong class="text-danger">*</strong></label>
                                        <div class="col-sm-9">
                                            <input  type="email" value="{{ auth()->guard('customer')->user()->email }} (Zertifiziert)"
                                                    class="form-control-plaintext @error('email') is-invalid @enderror"
                                                    disabled  >

                                            @error('email')
                                            <span class="invalid-feedback error" role="alert">
                                                     <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="name" class="col-sm-2 col-form-label">{{__('auth.customer_registration_form_input_password')}}<strong class="text-danger">*</strong></label>
                                        <div class="col-sm-9">
                                            <input  type="password"
                                                    name="password"
                                                    id="password"
                                                    class="form-control @error('password') is-invalid @enderror"  >

                                            @error('password')
                                            <span class="invalid-feedback error" role="alert">
                                                     <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="name" class="col-sm-2 col-form-label">Sprache <strong class="text-danger">*</strong></label>
                                        <div class="col-sm-9">
                                            <select name="lang" id="lang" class="form-control @error('lang') is-invalid @enderror">
                                                {{--<option value="">--</option>--}}
                                                <option {{  auth()->guard('customer')->user()->lang == 'en'  ? 'selected' : '' }} value="en">Englisch</option>
                                                <option {{  auth()->guard('customer')->user()->lang == 'de'  ? 'selected' : '' }}  value="de">Deutsch</option>
                                            </select>
                                            @error('lang')
                                            <span class="invalid-feedback error" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row mt-5">
                                        <label for="name" class="col-sm-2 col-form-label">Mobil-Nr</label>
                                        <div class="col-sm-9">

                                            @if (auth()->guard('customer')->user()->phone_number)
                                                <input  type="text" value="+{{ auth()->guard('customer')->user()->phone_code }} {{ auth()->guard('customer')->user()->phone_number }} (Zertifiziert)"
                                                        class="form-control-plaintext" disabled >
                                            @else
                                                <select name="phone_code" id="phone_code" class="form-control @error('phone_code') is-invalid @enderror">
                                                    @include('customer-portal.layout.partials.phone_codes')
                                                </select>
                                                @error('phone_code')
                                                <span class="invalid-feedback error" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                                @enderror
                                            @endif

                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="name" class="col-sm-2 col-form-label"></label>
                                        @if (!auth()->guard('customer')->user()->phone_number)
                                            <div class="col-sm-9">
                                                <input  type="text"  name="phone_number" id="phone_number"  class="form-control @error('phone_number') is-invalid @enderror" >
                                                @error('phone_number')
                                                <span class="invalid-feedback error" role="alert">
                                                        <strong>{{ $message }}</strong>
                                                    </span>
                                                @enderror
                                            </div>
                                        @endif

                                    </div>

                                </div>
                                <div class="col-6  justify-content-end">
                                    <div class="form-group row">
                                        <label for="name" class="col-sm-2 col-form-label">{{__('auth.customer_registration_form_input_company')}}</label>
                                        <div class="col-sm-9">
                                            <input  type="text" value="{{ auth()->guard('customer')->user()->company }}"
                                                    name="company"
                                                    id="company"
                                                    class="form-control @error('company') is-invalid @enderror"   >
                                            @error('company')
                                            <span class="invalid-feedback error" role="alert">
                                                    <strong>{{ $message }}</strong>

                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="name" class="col-sm-2 col-form-label">{{__('auth.customer_registration_form_input_road')}}{!! (auth()->guard('customer')->user()->phone_number or auth()->guard('customer')->user()->current_level() >= 2)  ? '<strong class="text-danger">*</strong>' : '' !!}  </label>
                                        <div class="col-sm-9">
                                            <input  type="text" value="{{ auth()->guard('customer')->user()->road }}"
                                                    name="road"
                                                    id="road"
                                                    class="form-control @error('road') is-invalid @enderror"  >
                                            @error('road')
                                            <span class="invalid-feedback error" role="alert">
                                                   <strong>{{ $message }}</strong>

                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="post_code" class="col-sm-2 col-form-label">{{__('auth.customer_registration_form_input_post_code')}} / {{__('auth.customer_registration_form_input_place')}} {!! (auth()->guard('customer')->user()->phone_number or auth()->guard('customer')->user()->current_level() >= 2)  ? '<strong class="text-danger">*</strong>' : '' !!}</label>
                                        <div class="col-sm-2">
                                            <input  type="text" value="{{ auth()->guard('customer')->user()->post_code }}"
                                                    id="post_code"
                                                    name="post_code"
                                                    class="form-control @error('post_code') is-invalid @enderror"  >
                                            @error('post_code')
                                            <span class="invalid-feedback error" role="alert">
                                                    <strong>{{ $message }}</strong>

                                                </span>
                                            @enderror
                                        </div>
                                        <div class="col-sm-7">
                                            <input  type="text" value="{{ auth()->guard('customer')->user()->place }}"
                                                    id="place"
                                                    name="place"
                                                    class="form-control @error('place') is-invalid @enderror"  >

                                            @error('place')
                                            <span class="invalid-feedback error" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                    </div>
                                    <div class="form-group row">
                                        <label for="country" class="col-sm-2 col-form-label">{{__('auth.customer_registration_form_input_country')}}{!! (auth()->guard('customer')->user()->phone_number or auth()->guard('customer')->user()->current_level() >= 2)  ? '<strong class="text-danger">*</strong>' : '' !!}</label>
                                        <div class="col-sm-9">
                                            <select name="country" id="country" current="{{auth()->guard('customer')->user()->country}}" class="form-control @error('country') is-invalid @enderror">
                                                <option value="">-</option>
                                                @foreach(countries()['top'] as $key => $country)
                                                    <option {{ $key == auth()->guard('customer')->user()->country  ? 'selected' : ''}} value="{{$key}}">{{$country}}</option>
                                                @endforeach
                                                <option  style="font-size: 5pt;   " disabled></option>
                                                <option  style="font-size: .2pt;  background-color: lightgray;" disabled></option>
                                                <option  style="font-size: 5pt;   " disabled></option>
                                                @foreach(countries()['normal'] as $key => $country)
                                                    <option {{ $key == auth()->guard('customer')->user()->country  ? 'selected' : ''}} value="{{$key}}">{{$country}}</option>
                                                @endforeach

                                            </select>
                                            @error('country')
                                            <span class="invalid-feedback error" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        {{--<label for="tax_no" class="col-sm-2 col-form-label">UID-Nr <i class="fas fa-info-circle text-success" title="Die UID Nummer dient der eindeutigen Kennzeichnung von Unternehmen, die ihren Sitz in der Europäischen Union haben,
und zwar im Sinne des Umsatzsteuerrechts. Sie ist für alle Unternehmen verpflichtend, die im Binnenmarkt Geschäfte tätigen."></i></label>--}}
                                        <label for="tax_no" class="col-sm-2 col-form-label">UID-Nr <i class="fas fa-info-circle text-success" title="UID-Nummer ist die Abkürzung für Umsatzsteueridentifikationsnummer. Sie dient der eindeutigen Kennzeichnung von Unternehmen, die ihren Sitz in der Europäischen Union haben, und zwar im Sinne des Umsatzsteuerrechts. Sie ist für alle Unternehmen verpflichtend, die im Binnenmarkt Geschäfte tätigen."></i></label>
                                        <div class="col-sm-9">
                                            <input  type="text" value="{{ auth()->guard('customer')->user()->tax_no }}" name="tax_no"  id="tax_no"  class="form-control @error('tax_no') is-invalid @enderror" >
                                            @error('tax_no')
                                            <span class="invalid-feedback error" role="alert">
                                                     <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary float-right update_customer_profile_btn ">{{__('customers-profile.update_profile_button')}}</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
    <script>
        $(document).ready(function (){
            $(document).on('submit', '#update_customer_profile', function (e) {
                e.preventDefault();
                var thisForm = $(this);
                console.log('Customer Profile update submit');



                let form_data = new FormData();

                let title_select = $('#title');
                let first_name_input = $('#first_name');
                let last_name_input = $('#last_name');
                let password_input = $('#password');
                let lang_select = $('#lang');
                let tax_no_input = $('#tax_no');
                let phone_code_select = $('#phone_code');
                let phone_number_input = $('#phone_number');
                let company_input = $('#company');
                let road_input = $('#road');
                let post_code_input = $('#post_code');
                let country_select = $('#country');
                let place_input = $('#place');


                let title = title_select.find(':selected').val();
                let first_name = first_name_input.val();
                let last_name = last_name_input.val();
                let password = password_input.val();
                let lang = lang_select.find(':selected').val();
                let tax_no = tax_no_input.val();
                let phone_code = phone_code_select.find(':selected').val();
                let phone_number = phone_number_input.val();
                let company = company_input.val();
                let road = road_input.val();
                let post_code = post_code_input.val();
                let place = place_input.val();
                let country = country_select.find(':selected').val();

                let field_required = 'Feld ist erforderlich';

                if (title_select.length){
                    console.log('title select exist');
                    if (!title) {
                        title_select.addClass('is-invalid');
                        title_select.next('.error').remove();
                        title_select.after('<small class="text-danger error">'+field_required+'</small>');
                        title_select.focus();
                        return;
                    } else
                        form_data.append('title', title);
                }

                if (first_name_input.length){
                    if (!first_name) {
                        first_name_input.addClass('is-invalid');
                        first_name_input.next('.error').remove();
                        first_name_input.after('<small class="text-danger error">'+field_required+'</small>');
                        first_name_input.focus();
                        return;
                    }else{
                        form_data.append('first_name', first_name);
                    }
                }

                if (last_name_input.length){
                    if (!last_name) {
                        last_name_input.addClass('is-invalid');
                        last_name_input.next('.error').remove();
                        last_name_input.after('<small class="text-danger error">'+field_required+'</small>');
                        last_name_input.focus();
                        return;
                    }else{
                        form_data.append('last_name', last_name);
                    }
                }

                if (!password) {
                    password_input.addClass('is-invalid');
                    password_input.next('.error').remove();
                    password_input.after('<small class="text-danger error">'+field_required+'</small>');
                    password_input.focus();
                    return;
                }else{
                    form_data.append('password', password);
                }

                if (!lang) {
                    lang_select.addClass('is-invalid');
                    lang_select.next('.error').remove();
                    lang_select.after('<small class="text-danger error">'+field_required+'</small>');
                    lang_select.focus();
                    return;
                }else{
                    form_data.append('lang', lang);
                }


                if (phone_number) {
                    if (!phone_code) {
                        phone_code_select.addClass('is-invalid');
                        phone_code_select.next('.error').remove();
                        phone_code_select.after('<small class="text-danger error">'+field_required+'</small>');
                        phone_code_select.focus();
                        return;
                    }else{
                        form_data.append('phone_code', phone_code);
                    }
                    if (phone_number[0] == 0){
                        phone_number_input.addClass('is-invalid');
                        phone_number_input.next('.error').remove();
                        phone_number_input.after('<small class="text-danger error">Ihre Mobil-Nr darf nicht mit einer 0 beginnen</small>');
                        phone_number_input.focus();
                        return;
                    }
                    var numbers = /^[0-9]+$/;
                    if(!phone_number.match(numbers))
                    {
                        phone_number_input.addClass('is-invalid');
                        phone_number_input.next('.error').remove();
                        phone_number_input.after('<small class="text-danger error">Die Telefonnummer darf nur Zahlen enthalten.</small>');
                        phone_number_input.focus();
                        return;
                    }

                    if (phone_number.length < 6){
                        console.log('phone_number length', phone_number.length)
                        phone_number_input.addClass('is-invalid');
                        phone_number_input.next('.error').remove();
                        phone_number_input.after('<small class="text-danger error">Ihre Mobil-Nr muss mindestens 6 Stellen haben</small>');
                        phone_number_input.focus();
                        return;
                    }
                    form_data.append('phone_number', phone_number);
                }

                form_data.append('company', company);
                @if (auth()->guard('customer')->user()->phone_number or auth()->guard('customer')->user()->current_level() >= 2)
                if (!road) {
                    road_input.addClass('is-invalid');
                    road_input.next('.error').remove();
                    road_input.after('<small class="text-danger error">'+field_required+'</small>');
                    road_input.focus();
                    return;
                }else{
                    form_data.append('road', road);
                }

                if (!post_code) {
                    post_code_input.addClass('is-invalid');
                    post_code_input.next('.error').remove();
                    post_code_input.after('<small class="text-danger error">'+field_required+'</small>');
                    post_code_input.focus();
                    return;
                }else{
                    form_data.append('post_code', post_code);
                }

                if (!place) {
                    place_input.addClass('is-invalid');
                    place_input.next('.error').remove();
                    place_input.after('<small class="text-danger error">'+field_required+'</small>');
                    place_input.focus();
                    return;
                }else{
                    form_data.append('place', place);
                }
                if (!country) {
                    country_select.addClass('is-invalid');
                    country_select.next('.error').remove();
                    country_select.after('<small class="text-danger error">'+field_required+'</small>');
                    country_select.focus();
                    return;
                }else{
                    form_data.append('country', country);
                }
                @else

                form_data.append('road', road);
                form_data.append('post_code', post_code);
                form_data.append('place', place);
                form_data.append('country', country);

                @endif

                form_data.append('tax_no', tax_no);

                console.log('ajax');
                $('.preloader').css('display', 'block');
                $.ajax({
                    type: "post",
                    url: '{{ route('customer.profile_update', auth()->guard('customer')->id()) }}',
                    headers: {'X-CSRF-Token': $('meta[name="csrf-token"]').attr('content')},
                    data: form_data,
                    contentType: false,
                    cache: false,
                    processData: false,
                    dataType: 'json',
                    success: (response) => {
                        $('.alert-block').append('<div class="alert alert-success alert-dismissible fade show" role="alert">'+response.message+'</div>');
                        console.log('success => ', response);
                        $("html, body").animate({ scrollTop: 0 }, "slow");
                        setTimeout(function(){
                            $('.alert-block').find('div').slideUp(500);
                            if(response.url){
                                setTimeout(function(){
                                    window.location.href = response.url;
                                }, 100);
                            }

                        }, 2000);

                    },
                    error: (error) => {
                        $("html, body").animate({ scrollTop: 0 }, "slow");
                        $('.preloader').css('display', 'none');
                        $('.alert-block').append('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+error.responseJSON.message  +'</div>');
                        setTimeout(function(){
                            $('.alert-block').find('div').slideUp(500);
                        }, 2000);
                        if ((error.responseJSON.hasOwnProperty('errors'))) {
                            if (error.responseJSON.errors.hasOwnProperty('title')) {
                                title_select.addClass('is-invalid');
                                title_select.next('.error').remove();
                                title_select.after('<small class="text-danger error">' + error.responseJSON.errors.title[0] + '</small>');
                                title_select.focus();
                                return;
                            }

                            if (error.responseJSON.errors.hasOwnProperty('first_name')) {
                                first_name_input.addClass('is-invalid');
                                first_name_input.next('.error').remove();
                                first_name_input.after('<small class="text-danger error">' + error.responseJSON.errors.first_name[0] + '</small>');
                                first_name_input.focus();
                                return;
                            }
                            if (error.responseJSON.errors.hasOwnProperty('last_name')) {
                                last_name_input.addClass('is-invalid');
                                last_name_input.next('.error').remove();
                                last_name_input.after('<small class="text-danger error">' + error.responseJSON.errors.last_name[0] + '</small>');
                                last_name_input.focus();
                                return;
                            }
                            if (error.responseJSON.errors.hasOwnProperty('password')) {
                                password_input.addClass('is-invalid');
                                password_input.next('.error').remove();
                                password_input.after('<small class="text-danger error">' + error.responseJSON.errors.password[0] + '</small>');
                                password_input.focus();
                                return;
                            }
                            if (error.responseJSON.errors.hasOwnProperty('lang')) {
                                lang_select.addClass('is-invalid');
                                lang_select.next('.error').remove();
                                lang_select.after('<small class="text-danger error">' + error.responseJSON.errors.lang[0] + '</small>');
                                lang_select.focus();
                                return;
                            }
                            if (error.responseJSON.errors.hasOwnProperty('tax_no')) {
                                tax_no_input.addClass('is-invalid');
                                tax_no_input.next('.error').remove();
                                tax_no_input.after('<small class="text-danger error">' + error.responseJSON.errors.tax_no[0] + '</small>');
                                tax_no_input.focus();
                                return;
                            }
                            if (error.responseJSON.errors.hasOwnProperty('phone_code')) {
                                phone_code_select.addClass('is-invalid');
                                phone_code_select.next('.error').remove();
                                phone_code_select.after('<small class="text-danger error">' + error.responseJSON.errors.phone_code[0] + '</small>');
                                phone_code_select.focus();
                                return;
                            }
                            if (error.responseJSON.errors.hasOwnProperty('phone_number')) {
                                phone_number_input.addClass('is-invalid');
                                phone_number_input.next('.error').remove();
                                phone_number_input.after('<small class="text-danger error">' + error.responseJSON.errors.phone_number[0] + '</small>');
                                phone_number_input.focus();
                                return;
                            }
                            if (error.responseJSON.errors.hasOwnProperty('company')) {
                                company_input.addClass('is-invalid');
                                company_input.next('.error').remove();
                                company_input.after('<small class="text-danger error">' + error.responseJSON.errors.company[0] + '</small>');
                                company_input.focus();
                                return;
                            }
                            if (error.responseJSON.errors.hasOwnProperty('road')) {
                                road_input.addClass('is-invalid');
                                road_input.next('.error').remove();
                                road_input.after('<small class="text-danger error">' + error.responseJSON.errors.road[0] + '</small>');
                                road_input.focus();
                                return;
                            }
                            if (error.responseJSON.errors.hasOwnProperty('post_code')) {
                                post_code_input.addClass('is-invalid');
                                post_code_input.next('.error').remove();
                                post_code_input.after('<small class="text-danger error">' + error.responseJSON.errors.post_code[0] + '</small>');
                                post_code_input.focus();
                                return;
                            }
                            if (error.responseJSON.errors.hasOwnProperty('country')) {
                                country_select.addClass('is-invalid');
                                country_select.next('.error').remove();
                                country_select.after('<small class="text-danger error">' + error.responseJSON.errors.country[0] + '</small>');
                                country_select.focus();
                                return;
                            }
                            if (error.responseJSON.errors.hasOwnProperty('place')) {
                                place_input.addClass('is-invalid');
                                place_input.next('.error').remove();
                                place_input.after('<small class="text-danger error">' + error.responseJSON.errors.place[0] + '</small>');
                                place_input.focus();
                                return;
                            }


                        }
                    },
                    beforeSend: () => {
                        title_select.removeClass('is-invalid');
                        title_select.next('.error').remove();

                        first_name_input.removeClass('is-invalid');
                        first_name_input.next('.error').remove();

                        last_name_input.removeClass('is-invalid');
                        last_name_input.next('.error').remove();

                        password_input.removeClass('is-invalid');
                        password_input.next('.error').remove();

                        lang_select.removeClass('is-invalid');
                        lang_select.next('.error').remove();

                        tax_no_input.removeClass('is-invalid');
                        tax_no_input.next('.error').remove();

                        phone_code_select.removeClass('is-invalid');
                        phone_code_select.next('.error').remove();

                        phone_number_input.removeClass('is-invalid');
                        phone_number_input.next('.error').remove();

                        company_input.removeClass('is-invalid');
                        company_input.next('.error').remove();

                        road_input.removeClass('is-invalid');
                        road_input.next('.error').remove();

                        post_code_input.removeClass('is-invalid');
                        post_code_input.next('.error').remove();

                        country_select.removeClass('is-invalid');
                        country_select.next('.error').remove();

                        place_input.removeClass('is-invalid');
                        place_input.next('.error').remove();


                    },
                    complete: () => {

                    }
                });
            })
        });

    </script>
@endsection

