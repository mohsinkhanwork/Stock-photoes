<div class="modal fade" id="bid_auction_modal"
     tabindex="-1" role="dialog" style="z-index: 99999999999;">
    <div class="modal-dialog  " role="document">
        <div class="modal-content">
            <div class="modal-header" style="padding-top: 5px; padding-bottom: 5px;">
                <h5 class="modal-title title" id="defaultModalLabel"> </h5>
            </div>
            <div class="modal-body">
                <p class="message"></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary btn-sm close-button"  data-dismiss="modal"> </button>
            </div>

        </div>
    </div>
</div>
<div class="modal fade" id="confirm_bid_auction_modal" tabindex="-1" role="dialog" style="z-index: 99999999999;">
    <div class="modal-dialog  " role="document">
        <div class="modal-content">
            <div class="modal-header" style="padding-top: 5px; padding-bottom: 5px;">
                <h5 class="modal-title title" id="defaultModalLabel"> </h5>
            </div>
            <div class="modal-body">
                <p class="message"></p>
                <p class="domain text-bold"></p>
                <p class="price_confirmation"></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-sm close-button"  data-dismiss="modal"> Abbrechen</button>
                <button type="button" class="btn btn-primary btn-sm submit_bid_auction_button"> Bestätigen </button>
            </div>

        </div>
    </div>
</div>
