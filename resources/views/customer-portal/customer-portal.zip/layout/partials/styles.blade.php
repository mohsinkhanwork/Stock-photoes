<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
<link rel="stylesheet" href="{{asset('themes/fontawesome-free/css/all.min.css')}}">
<link rel="stylesheet" href="{{asset('themes/data-table/css/data-table-bootstrap.css')}}">
<link rel="stylesheet" href="{{asset('themes/select2/css/select2.min.css')}}">
<link rel="stylesheet" href="{{asset('themes/select2-bootstrap4-theme/select2-bootstrap4.min.css')}}">
<link rel="stylesheet" href="{{asset('themes/daterangepicker/daterangepicker.css')}}">
<link rel="stylesheet" href="{{asset('themes/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css')}}">
<link rel="stylesheet" href="{{asset('css/adomino-theme.min.css')}}">
<link rel="stylesheet" href="{{asset('css/adomino.css')}}">
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet"/>
<link href="{{ asset('css/modules/auction.css') }}" rel="stylesheet">
